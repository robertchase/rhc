from distutils.core import setup
setup(
    name='rhc',
    version='1.6',
    packages=['rhc'],
)
